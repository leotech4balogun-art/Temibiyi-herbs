TEMIBIYI HERBS MANAGER — V2 (iPad/PWA)

This version keeps the working sales, stock, expenses, customers, reports and receipt features,
and adds Progressive Web App support for iPad/iPhone/laptop.

iPad installation:
1. The app must be opened from a web address (HTTPS) for Safari's Add to Home Screen and
   service-worker offline mode to work reliably.
2. Open the app URL in Safari.
3. Tap Share.
4. Tap Add to Home Screen.
5. Tap Add.
6. Launch Temibiyi Herbs from the new Home Screen icon.

IMPORTANT:
The downloadable package is offline-first. It does NOT contain a shared cloud database because
a real cloud database requires a database project and private connection credentials.
The app includes backup/restore and is structured for the next cloud-sync stage.

Business:
Temibiyi Herbs
08086689511 / 09029424609
