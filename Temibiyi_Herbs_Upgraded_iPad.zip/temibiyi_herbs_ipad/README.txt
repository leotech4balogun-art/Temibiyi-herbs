TEMIBIYI HERBS MANAGER — upgraded iPad web app

Features:
- Admin/Cashier sign-in (local device only), default PIN 1234
- Sales, stock, expenses and reports
- EDIT STOCK button: rename stock/herb after input and change quantity/cost/selling price
- Stock automatically reduces when a matching product is sold
- CSV sales export
- JSON backup and restore
- iPad Home Screen friendly

Important: this static version stores data locally on the device. It is not yet a true cloud-synced multi-device system. A production cloud version needs a backend/database and secure authentication.
